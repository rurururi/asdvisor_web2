<x-filament::page>
    <livewire:care-decision />
</x-filament::page>