<span class="text-sm font-medium leading-6 text-gray-950 dark:text-white">
Image
</span>
<img src='https://{{ $_SERVER['SERVER_NAME'] }}/storage/{{$getState()}}' size="w-16 h-16" class="w-auto"/>