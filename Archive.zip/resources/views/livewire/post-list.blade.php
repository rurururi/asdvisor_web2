<div class="container mx-auto">
  <div class="mx-4 md:mx-auto my-20 max-w-md md:max-w-2xl flex flex-col">
        @if(count($posts) != 0)
            @foreach ($posts as $post)
                <?php
                $words = explode(" ", $post->user->name);
                $acronym = "";
                
                foreach ($words as $w) {
                $acronym .= mb_substr($w, 0, 1);
                }
                ?>
                <div class="px-4 py-6 flex items-start mb-10 w-auto rounded-lg shadow-lg bg-white dark:bg-gray-900 text-black dark:text-white" key="{{$post->id}}">
                    <div class="w-16 h-16 mr-4">
                        <img src="https://placehold.co/100x100?text={{$acronym}}" class="rounded-full shadow object-cover"/>
                    </div>
                    <div class="w-full">
                        <div class="flex items-center justify-start">
                            <h2 class="-mt-1 mr-1 text-lg text-gray-900 dark:text-white font-semibold">{{$post->user->name}} 
                            ({{$post->user->account_level == "Parents" ? "Parent" :$post->user->account_level}})</h2>
                        </div>
                        <div class="text-sm text-gray-500">{{ \Carbon\Carbon::parse($post->created_at)->format('M d, Y h:i A') }} </div>
                        <div class="mt-3 text-sm text-gray-700 dark:text-white border-slate-100 border-solid border-b-2 pb-2">{{$post->body}}</div>
                        
                        <div class="my-2">
                            <livewire:comments :model="$post"/>
                        </div>
                    </div>
                </div>
            @endforeach

            {{ $posts->links() }}
        @endif
        @if(count($posts) == 0)
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">Holy smokes!</strong>
                <span class="block sm:inline">No results found.</span>
            </div>
        @endif
    </div>    
</div>