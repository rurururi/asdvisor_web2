<?php

return [
    'users_route_prefix' => 'users', //set this prefix to anything that you wish to use for users profile routes
    'pagination_count' => 3,
    'css_framework' => 'tailwind', // or 'bootstrap'
    'comment_nesting' => false, // set to false if you don't want to allow nesting of comments

];
