<div>
<meta http-equiv="refresh" content="0; url=../community">
</div><?php /**PATH /Users/harveyarboleda/Desktop/asdvisor/resources/views/livewire/post-index.blade.php ENDPATH**/ ?>