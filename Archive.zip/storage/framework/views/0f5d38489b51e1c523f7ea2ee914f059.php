<!doctype html>
<html>
    <head>
            <title>Community | Asdvisor</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
            <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
            <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
            <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    </head>
    <body class="bg-white">
        <span class="absolute text-white text-4xl top-5 left-4 cursor-pointer" onclick="openSidebar()">
            <i class="fa-solid fa-bars text-xl px-3 py-2 bg-gray-900 rounded-md"></i>
        </span>
        
        <div class="sidebar fixed top-0 bottom-0 lg:left-0 p-2 w-[300px] overflow-y-auto text-center bg-gray-900">
            <div class="text-gray-100 text-xl">
                <div class="p-2.5 mt-1 flex items-center">
                    <i class="fa-solid fa-house px-2 py-2 rounded-md bg-blue-600"></i>
                    <h1 class="font-bold text-gray-200 text-[15px] ml-3">Asdvisor</h1>
                    <i class="fa-solid fa-xmark cursor-pointer absolute right-4"
                        onclick="openSidebar()"
                        ></i>
                </div>
                <div class="my-2 bg-gray-600 h-[1px]"></div>
            </div>
            <a href="https://<?php echo $_SERVER['SERVER_NAME']; ?>/web" class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white">
                <i class="fa-solid fa-house"></i>
                <span class="text-[15px] ml-4 text-gray-200 font-bold">Back to Home</span>
            </a>
            <div class="my-4 bg-gray-600 h-[1px]"></div>
            <a href="https://<?php echo $_SERVER['SERVER_NAME']; ?>/community/create" class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white">
                <i class="fa-solid fa-file"></i>
                <span class="text-[15px] ml-4 text-gray-200 font-bold">Create Post</span>
            </a>
            <div class="my-4 bg-gray-600 h-[1px]"></div>
            
            <div
                class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white"
                onclick="dropdown()"
                >
                <i class="fa-solid fa-list"></i>
                <div class="flex justify-between w-full items-center">
                    <span class="text-[15px] ml-4 text-gray-200 font-bold">Categories</span>
                    <span class="text-sm rotate-180" id="arrow">
                    <i class="fa-solid fa-caret-down"></i>
                    </span>
                </div>
            </div>
            <div
                class="text-left text-sm mt-2 w-4/5 mx-auto text-gray-200 font-bold"
                id="submenu"
                >
                <a href="https://<?php echo $_SERVER['SERVER_NAME']; ?>/community">
                    <h1 class="cursor-pointer p-2 hover:bg-blue-600 rounded-md mt-1">
                        All
                    </h1>
                </a>
                <?php
                    $categories = \App\Models\Category::get();
                ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="https://<?php echo $_SERVER['SERVER_NAME']; ?>/community?category=<?php echo e($category->id); ?>">
                    <h1 class="cursor-pointer p-2 hover:bg-blue-600 rounded-md mt-1">
                        <?php echo e($category->name); ?>

                    </h1>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="my-4 bg-gray-600 h-[1px]"></div>
            <span class="font-bold text-white mb-4 block">Hello, <?php echo e(auth()->user()->name); ?>!</span>
            <form
                action="<?php echo e(filament()->getLogoutUrl()); ?>"
                method="post"
                class="my-auto"
            >
                <?php echo csrf_field(); ?>

                <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'gray','icon' => 'heroicon-m-arrow-left-on-rectangle','iconAlias' => 'panels::widgets.account.logout-button','labeledFrom' => 'sm','tag' => 'button','type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'gray','icon' => 'heroicon-m-arrow-left-on-rectangle','icon-alias' => 'panels::widgets.account.logout-button','labeled-from' => 'sm','tag' => 'button','type' => 'submit']); ?>
                    <?php echo e(__('filament-panels::widgets/account-widget.actions.logout.label')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
            </form>
        </div>

        <?php echo e($slot); ?>

  
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


        <script type="text/javascript">
            function dropdown() {
                document.querySelector("#submenu").classList.toggle("hidden");
                document.querySelector("#arrow").classList.toggle("!rotate-0");
            }
            dropdown();

            function openSidebar() {
                document.querySelector(".sidebar").classList.toggle("hidden");
            }
            openSidebar();
        </script>
    </body>
</html><?php /**PATH /Users/harveyarboleda/Desktop/asdvisor/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>