<div class="container mx-auto">
  <div class="mx-4 md:mx-auto my-20 max-w-md md:max-w-2xl flex flex-col">
        <!--[if BLOCK]><![endif]--><?php if(count($posts) != 0): ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $words = explode(" ", $post->user->name);
                $acronym = "";
                
                foreach ($words as $w) {
                $acronym .= mb_substr($w, 0, 1);
                }
                ?>
                <div class="px-4 py-6 flex items-start mb-10 w-auto rounded-lg shadow-lg bg-white dark:bg-gray-900 text-black dark:text-white" key="<?php echo e($post->id); ?>">
                    <div class="w-16 h-16 mr-4">
                        <img src="https://placehold.co/100x100?text=<?php echo e($acronym); ?>" class="rounded-full shadow object-cover"/>
                    </div>
                    <div class="w-full">
                        <div class="flex items-center justify-start">
                            <h2 class="-mt-1 mr-1 text-lg text-gray-900 dark:text-white font-semibold"><?php echo e($post->user->name); ?> 
                            (<?php echo e($post->user->account_level == "Parents" ? "Parent" :$post->user->account_level); ?>)</h2>
                        </div>
                        <div class="text-sm text-gray-500"><?php echo e(\Carbon\Carbon::parse($post->created_at)->format('M d, Y h:i A')); ?> </div>
                        <div class="mt-3 text-sm text-gray-700 dark:text-white border-slate-100 border-solid border-b-2 pb-2"><?php echo e($post->body); ?></div>
                        
                        <div class="my-2">
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('comments', ['model' => $post]);

$__html = app('livewire')->mount($__name, $__params, '4Vjdo47', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

            <?php echo e($posts->links()); ?>

        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if(count($posts) == 0): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">Holy smokes!</strong>
                <span class="block sm:inline">No results found.</span>
            </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </div>    
</div><?php /**PATH /Users/harveyarboleda/Desktop/asdvisor/resources/views/livewire/post-list.blade.php ENDPATH**/ ?>