<?php

namespace App\Livewire;

use App\Models\Post;
use Livewire\Component;
use Livewire\WithPagination;

class PostList extends Component
{
    use WithPagination;

    public $category;

    public function render()
    {
        $this->category = $_GET['category'] ?? NULL;
        $post = null;
        if($this->category == "1" || $this->category == "2" || $this->category == "3") {
            $post = Post::where('category_id', $this->category)->orderBy('id', 'DESC')->paginate(10);
        } else {
            $post = Post::orderBy('id', 'DESC')->paginate(10);
        }

        return view('livewire.post-list', [
            'posts' => $post
        ]);
    }
}
