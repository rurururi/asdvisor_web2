<?php

namespace App\Filament\Resources\ChildInformationHistoryResource\Pages;

use App\Filament\Resources\ChildInformationHistoryResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewChildInformationHistory extends ViewRecord
{
    protected static string $resource = ChildInformationHistoryResource::class;
}
