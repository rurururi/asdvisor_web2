<?php

namespace App\Filament\Resources\ChildStatsHistoryResource\Pages;

use App\Filament\Resources\ChildStatsHistoryResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewChildStatsHistory extends ViewRecord
{
    protected static string $resource = ChildStatsHistoryResource::class;
}
